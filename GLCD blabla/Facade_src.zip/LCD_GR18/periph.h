#ifndef PERIPH_H
#define PERIPH_H

#include "lcd_port.h"

//========================================================================================
//   CLAVIER  
//========================================================================================
// Lecture de la touche appuyee (clavier matrice) : 1-9, 10(0), 11(*), 12(#)
unsigned char 
clavier(void);

// antirebond touche x
void
clavier_antirebond(unsigned char touche);

#endif

// lcd_port.h
//   configuration des entrees sorties

#ifndef LCD_PORT_H
#define LCD_PORT_H
///#include <pic1687x.h>
#include <pic18.h>
#include <pic18fxx2.h>


// Config Quartz + Debit RS232
#define BAUD 115200      
//#define FOSC 32000000L 		// 8MHz HSPLL x4
#define FOSC 48000000L 		// 12MHz HSPLL x4
//#define FOSC 12000000L		// 12MHz HS

#define NINE 0					// Use 9bit communication? FALSE=8bit 
#define OUTPUT 0
#define INPUT 1

#define DIVIDER ((int)(FOSC/(16UL * BAUD) -1))
#define HIGH_SPEED 1

#if NINE == 1
	#define NINE_BITS 0x40
#else
	#define NINE_BITS 0
#endif

#if HIGH_SPEED == 1
	#define SPEED 0x4
#else
	#define SPEED 0
#endif


#define FREQ_MULT	(FOSC)/(4000000L)



//--- TIMER0 ---
#define OPTION_TMR0 0b10000111	// pullUp off, tmr0-> presc 256


//--- CLAVIER ---
#define TRIS_CLAV	0b00001111	// D4-D7 : out D0-D3 : IN
#define TRIS_NORM	0b00000000	// data output
#define CLAV_DATA	PORTD		// data port
//#define CLAV_PORT	0x08		// port clavier ASM

/*
//--- ANALOGIQUE ---
#define V_SUP		RA1		// entree ana surveillance 12V pour stockage param (mise hors tension)
*/

//--- AFFICHEUR LCD graphique ---
#define LCD_RS_DI	RE0		// Data / commande
#define LCD_R_W	RE1		// lecture / ecriture
#define LCD_EN		RE2		// Enable
#define LCD_DATA	PORTD		// D7-D0
#define LUM_RL		RB3		// backlight faible / fort
#define LCD_TRIS	TRISD		//
#define LCD_CS1	RB1		// chip select lcd cot� gauche
#define LCD_CS2	RB2		// chip select lcd cot� droit

/*
//--- BUS I2C ---
#define SCL			RC4		// clock 
#define SDA			RC3		// data


//--- PORT SERIE UART 9600bds/115kbds ---
#define RX232		RC7		// port serie
#define TX232		RC6		// idem 
*/

#define TRISA_CONF 0b11111111
#define TRISB_CONF 0b11000000
#define TRISC_CONF 0b11011111
#define TRISD_CONF 0b11111111
#define TRISE_CONF 0b00000000

//========================================================================================
// Bitmap en memoire i2c 24C256
//           pageMem    // Description		       pageMemReel = pageMem>>1
//========================================================================================
#define bmp0	0			// seb scope				
#define bmp1	4			// winamp					
#define bmp2	8			// symbol
#define bmp3	20			// USA
#define bmp4	16			// go wild
#define bmp5	12			// graph data
#define bmp6	24			// Alarme (voiture)		
#define bmp7	28			// G12032
#define bmp8	32			// lextronic
#define bmp9	36			// V
#define bmp10	40			// V
#define bmp11	44			// V
#define bmp12	48			// V
#define bmp13	52			// V
#define bmp14	56			// V
#define bmp15	60			// V
#define bmp16	64			// menu Principal
#define bmp17	68			// menu Scope
#define bmp18	72			// menu Dat8
#define bmp19	76			// menu Tra2	(transfert Bootloader)
#define bmp20	80			// menuCal2	: ampoule off
#define bmp21	84			// menuCal2	: ampoule on
#define bmp22	88			// menuSco3 : menu param scope
#define bmp23	92			// menuI2C  : transfert bitmap
#define bmp24	96			// menuAide : copyright
#define bmp25	100		// V
#define bmp26	104		// V
#define bmp27	108		// V
#define bmp28	112		// V
#define bmp29	116		// V
#define bmp30	120		// V
#define bmp31	124		// V


#endif


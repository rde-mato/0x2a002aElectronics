#ifndef I2C_H
#define I2C_H

#include "delay.h"

//========================================================================================
//   BUS I2C : fonctions de base
//========================================================================================
void
i2c_init(void);										// i2c_init  - initialize I2C functions

void
i2c_waitForIdle(void);

void
i2c_start(void);										// i2c_start - issue Start condition

void
i2c_repStart(void);									// i2c_repStart- issue Repeated Start condition

void
i2c_stop(void);										// i2c_stop  - issue Stop condition

int  
i2c_read( unsigned char ack );				// i2c_read(x) - receive unsigned char 
															// - x=0, don't acknowledge - x=1, acknowledge
															// i2c_write - write unsigned char - returns ACK
unsigned char 
i2c_write( unsigned char i2cWriteData );

//========================================================================================
// memoire I2C		24LC256 (32ko)
//========================================================================================
void
rw_start_eeprom(unsigned int address, unsigned char data);		// start read/write

void
write_ext_eeprom(unsigned int address, unsigned char data);		// ecriture

unsigned char 
read_ext_eeprom(unsigned int address);									// lecture


#endif

#include "i2c.h"

//========================================================================================
// BUS I2C 
//========================================================================================
void
i2c_init(void) {
	TRISC3=1;	TRISC4=1;			// set SCL and SDA pins as inputs
	SSPCON1 = 0x38;					// set I2C master mode
	SSPCON2 = 0x00;	
	// SSPADD = Fosc/(Fi2c*4)-1				
	SSPADD = 0x1D;						// Fi2c= Fosc/(4*(SSPADD+1))   ; 0x1D 400kHz bus with 48MHz xtalPLL
//	SSPADD = 0x0E;						// Fi2c= Fosc/(4*(SSPADD+1))   ; 0x0C 400kHz bus with 20MHz xtal
	CKE=0;								// use I2C levels      worked also with '0'
	SMP=0;								// disable slew rate control  worked also with '0'
	PSPIF=0;								// clear SSPIF interrupt flag
	BCLIF=0;								// clear bus collision flag
}
//========================================================================================
void
i2c_waitForIdle(void) {
	while (( SSPCON2 & 0x1F ) | RW ) {}; // wait for idle and not writing
}
//========================================================================================
void
i2c_start(void) {
	i2c_waitForIdle();
	SEN=1;
}
//========================================================================================
void
i2c_repStart(void) {
	i2c_waitForIdle();
	RSEN=1;
}
//========================================================================================
void
i2c_stop(void){
	i2c_waitForIdle();
	PEN=1;
}
//========================================================================================
int 
i2c_read( unsigned char ack ){
	unsigned char i2cReadData;
	i2c_waitForIdle();
	RCEN=1;
	i2c_waitForIdle();
	i2cReadData = SSPBUF;
	i2c_waitForIdle();
	if (ack)	ACKDT=0;
	else		ACKDT=1;
	ACKEN=1;               			// send acknowledge sequence
	return( i2cReadData );
}
//========================================================================================
unsigned char 
i2c_write( unsigned char i2cWriteData ){
	i2c_waitForIdle();
	SSPBUF = i2cWriteData;
	return ( ! ACKSTAT  ); 			// function returns '1' if transmission is acknowledged
}
//========================================================================================
/*
void
rw_start_eeprom(unsigned int address, unsigned char data){
	i2c_start();
	i2c_write(0xa0);
	i2c_write(address << 8);
	i2c_write(address & 0x00FF);	
}*/
//========================================================================================
/*
void
write_ext_eeprom(unsigned int address, unsigned char data){
	rw_start_eeprom(address, data);
	i2c_write(data);
	i2c_stop();
	DelayMs(11);
}*/
//========================================================================================
/*unsigned char 
read_ext_eeprom(unsigned int address){
	unsigned char data;
	rw_start_eeprom(address, data);	
	i2c_repStart();
	i2c_write(0xa1);
	data = i2c_read(0);							// nack (1 data � lire)
	i2c_stop();
	return(data);
}*/



#ifndef RS232_H
#define RS232_H
#include "lcd_port.h"

//========================================================================================
//   RS232
//========================================================================================
void
init232(char debit);

void
tx232(char val);

char 
rx232(void);

void
tx232_puts(const char * s);		// ecrit une string de caracteres sur le port serie

void
tx232_2ascii(unsigned char car);	// ecrit 2 caracteres ascii 

unsigned char 
hexa2ascii(unsigned char tmp);	// convertit un nombre hexadecimal en ascii


#endif

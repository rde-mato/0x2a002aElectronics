#include "delay.h"

//============================================================================
//  Tempos
//============================================================================
void 
DelayBigMs(unsigned char d)
{
	unsigned char tmp1, tmp2;
	for(tmp1=d; tmp1!=0; tmp1--) {
		for(tmp2=255; tmp2!=0; tmp2--) {
			asm("nop");		
		}
	}	
}

void
DelayUs(unsigned char x)	{
	/*unsigned int _dcnt; // char??
	if(x>=4) _dcnt=(x*(FREQ_MULT)/2); 
	else _dcnt=1; 
	for( ; _dcnt!=0; _dcnt--) //while(--_dcnt > 0) 
	{
		asm("nop");
		asm("nop");
		//continue; 
	} */
	unsigned char tmp1, tmp2;
	for(tmp2 = x; tmp2!=0; tmp2--) {					
		// si 48MHz => FRQ_MULT = 48;  12cycles => 1us
		for(tmp1 = FREQ_MULT>>2; tmp1!=0; tmp1--) {
			asm("nop");
			asm("nop");	
		}
	}
}

void
DelayMs(unsigned char cnt)
{
	unsigned char i;
	while (cnt--) {
		i=4;
		while(i--) {
			DelayUs(109);	/* Adjust for error */
		} ;
	} ;
}


//========================================================================================
/* Temporisation I2C */
/*
void
DelayMs(unsigned char cnt){
	TEMPO(); TEMPO();
}*/

/*
void
DelaySec(char sec){
	char loop;
	for(loop=0;loop<=(sec<<2);loop++) DelayMs(250); // sec*4
}*/


//========================================================================================
void
tempo_x65ms(unsigned char nbr){
	unsigned char tmp1b, tmp2, tmp3; // tmp1=255: 65ms     
	for(tmp3=nbr;tmp3>0;tmp3--){
		for(tmp1b=255;tmp1b>0;tmp1b--)
			for(tmp2=255;tmp2>0;tmp2--)asm("nop");
	}
}

//========================================================================================
/* Temporisation pour le LCD */
// 513us (asm:579.25us (2317 cycles)) 16MHz
//========================================================================================
void
TEMPO(void){
	unsigned char tmp1b, tmp2; // tmp1=2: 512.75us     
	for(tmp1b=2;tmp1b>0;tmp1b--)
		for(tmp2=255;tmp2>0;tmp2--)asm("nop");
}

void
DELAY500(void){					// tempo 125us (500/4)
	unsigned char tmp;
	for(tmp=125;tmp>0;tmp--)asm("nop");
}

void
X_DELAY500(unsigned char val){	// val * 125us
	unsigned char tmp;
	for(tmp=val;tmp>0;tmp--) DELAY500();
}

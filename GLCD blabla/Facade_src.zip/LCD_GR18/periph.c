volatile unsigned char touche;

//========================================================================================
//  CLAVIER
//  Renvoie le numero de touche appuyee dans 'touche' et dans w (2.33ms 9331 c)
//========================================================================================
unsigned char
clavier(void){ 
/*	// #debug
	if (RCIF) {
		touche = rx232();
		if (touche>='1') { //&&(touche<='<')) {
			tx232(touche);	
			return (touche-'0');	// -48
		// '1' -> 1, ..., '9' -> 9, ':' -> 0, ';' -> *, '<' -> #  	
		}
	}
	FLAG_GIE_SAVE;
	TRISD = TRIS_CLAV;
	CLAV_DATA = 0x01;	//D0
	TEMPO();
#asm
	clrf	_touche			; touche = 0
	movlw	0			; aucune touche
	btfsc	CLAV_PORT,4	; bp 1
	movlw	1
	btfsc	CLAV_PORT,5	; bp 2
	movlw	2
	btfsc	CLAV_PORT,6	; bp 3
	movlw	3
	movwf	_touche			; sauvegarde touche
#endasm
	CLAV_DATA = 0x02;	// D1
	TEMPO();
#asm
	movf	_touche,w		; restauration touche
	btfsc	CLAV_PORT,4	; bp 4
	movlw	4
	btfsc	CLAV_PORT,5	; bp 5
	movlw	5
	btfsc	CLAV_PORT,6	; bp 6
	movlw	6
	movwf	_touche			; sauvegarde touche
#endasm
	CLAV_DATA = 0x04;	// D2
	TEMPO();
#asm
	movf	_touche,w		; restauration touche
	btfsc	CLAV_PORT,4	; bp 7
	movlw	7
	btfsc	CLAV_PORT,5	; bp 8
	movlw	8
	btfsc	CLAV_PORT,6	; bp 9
	movlw	9
	movwf	_touche			; sauvegarde touche		
#endasm
	CLAV_DATA = 0x08;	// D3
	TEMPO();
#asm
	movf	_touche,w		; restauration touche
	btfsc	CLAV_PORT,4	; bp *
	movlw	11
	btfsc	CLAV_PORT,5	; bp 0
	movlw	10
	btfsc	CLAV_PORT,6	; bp #
	movlw	12
	movwf	_touche
#endasm
	CLAV_DATA = 0;
///	TRISD = TRIS_NORM;
	TRISD = 0xFF;		// all input
	FLAG_GIE_REST;
	return touche;*/
	
	///FLAG_GIE_SAVE;
	touche = 0;
	TRISD = TRIS_CLAV;
	CLAV_DATA = 0x80;	//D7
	TEMPO();
	if (CLAV_DATA & 0x01) touche = 1;	// bp1
	if (CLAV_DATA & 0x02) touche = 2;	// bp2
	if (CLAV_DATA & 0x04) touche = 3;	// bp3
	if (CLAV_DATA & 0x08) touche = 11;	// bpA
	
	CLAV_DATA = 0x40;	//D6
	TEMPO();
	if (CLAV_DATA & 0x01) touche = 4;	// bp4
	if (CLAV_DATA & 0x02) touche = 5;	// bp5
	if (CLAV_DATA & 0x04) touche = 6;	// bp6
	if (CLAV_DATA & 0x08) touche = 12;	// bpB

	CLAV_DATA = 0x20;	//D5
	TEMPO();
	if (CLAV_DATA & 0x01) touche = 7;	// bp7
	if (CLAV_DATA & 0x02) touche = 8;	// bp8
	if (CLAV_DATA & 0x04) touche = 9;	// bp9
	if (CLAV_DATA & 0x08) touche = 13;	// bpC


	// OK
	CLAV_DATA = 0x10;	//D6
	TEMPO();
	if (CLAV_DATA & 0x01) touche = 16;	// bp*
	if (CLAV_DATA & 0x02) touche = 10;	// bp0
	if (CLAV_DATA & 0x04) touche = 15;	// bpE
	if (CLAV_DATA & 0x08) touche = 14;	// bpD
	
	CLAV_DATA = 0;
///	TRISD = TRIS_NORM;
	TRISD = 0xFF;		// all input
	///FLAG_GIE_REST;

	return touche;
	
}

//========================================================================================
// antirebond touche x
//========================================================================================
void
clavier_antirebond(unsigned char touche){
	while(clavier()==touche); 								// antirebond 2 passes
	tempo_x65ms(1);											// pause 43ms
}			
	
	

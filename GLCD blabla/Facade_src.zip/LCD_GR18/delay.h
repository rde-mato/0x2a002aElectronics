#ifndef DELAY_H
#define DELAY_H

//========================================================================================
//  Tempos
//============================================================================
void 
DelayBigMs(unsigned char d);

void
DelayUs(unsigned char x);

void
DelayMs(unsigned char cnt);


//========================================================================================
//   Temporisation I2C  
//========================================================================================
/*#define	DelayUs(x)	{ unsigned char _dcnt; \
			  _dcnt = (x); \
			  while(--_dcnt != 0) \
				  continue; }
// x*16/12=2
DelayMs(unsigned char);
//void DelaySec(char sec);*/

//========================================================================================
//   Temporisation pour le LCD  
//========================================================================================
void
tempo_x65ms(unsigned char nbr);

void
TEMPO(void);													// 513us (lcd + clavier)

void
DELAY500(void);												// 125us (500/4)

void
X_DELAY500(unsigned char val);							// val * 125us

#endif


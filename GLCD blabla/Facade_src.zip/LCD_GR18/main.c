//========================================================================================
//   NOM:      main.c                                                                      
//   Date:     12/03/2004                                                                     
//   Version:  1.00                                                                        
//   Circuit:  circuit test PIC + LCD                                    
//   Compiler: Hi-Tech C18 v8.20PL4 www.htsoft.com
//   Auteur:   Sebastien JEFFROY                                                                          
//   Micro:    PIC18F452 12MHz*4 -> tcycl = 0.0833 us (1/12 us)                                                                             
//========================================================================================
//   Mise a jours :
//           12/03/04 : LCD 128x64 + RS232 + I2C
//           A FAIRE  :
//                      TEMPO precises + near variables + bootloader
//========================================================================================
//   Email   : sj29fr@yahoo.fr
//   Site    : http://sjeffroy.free.fr
//
//--------- GNU GPL LICENCE --------------------------------------------------
//	This file is subject to the terms of the GNU General Public License as
//	published by the Free Software Foundation.  A copy of this license is
//	included with this software distribution in the file COPYING.  If you
//	do not have a copy, you may obtain a copy by writing to the Free
//	Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
//
//	This software is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details
//========================================================================================


#include "lcd_port.h"
#include "rs232.c"							// RS232
#include "i2c.c"								// I2C
#include "delay.c"
#include "periph.c"							// clavier +....

#include "lcd.h"								// 128x64


//========================================================================================
// Fusibles Config

__CONFIG(1, HSPLL & OSCSDIS);// HS w/PLL Enabled, Clk Freq = 4xFreq Osc.
//__CONFIG(1, HS & OSCSDIS); // for freq>8Mhz and <20Mhz, use XT instead of HS for <8Mhz
__CONFIG(2,BORDIS & WDTDIS); // BORDIS=brown out reset disabled, WDTDIS=watch dog timer disabled
__CONFIG(4,DEBUGDIS & LVPDIS & STVRDIS); // DEBUGDIS=debug disabled, LVPDIS=low voltage programmin disabled
__CONFIG(5,UNPROTECT); //unprotected
__CONFIG(6,WRTEN); //flash write enabled
__CONFIG(7,TRU); //all unprotected including boot block
//========================================================================================


unsigned char bufferRX[64];
unsigned char indexRX = 0;
static bit serialRX;


//========================================================================================
//  initialisation des parametres
//========================================================================================
init_system(void){
	//=============== INITIALISATION DES PORTS I/O ===============//
	PORTA = 0;								// Sorties portA a 0
	PORTB = 0;								// sorties portB a 0
//	PORTC &= 0xC0;							// sorties portC a 0
	PORTC = 0x00;							// sorties portC a 0
	PORTD = 0;								// sorties portD a 0
	PORTE = 0;								// sorties portE a 0
	

//	ADCON0 = 0x85;							// 0b10000101 (Fosc/32, RA0, GO, 0, A/D on)
	ADCON0 = 0xC5;
	ADCON1 = 0x0E;							// 0b00001110 (left justify (8bits), RA0 ana)


	/*PSPMODE = 0;//???
	LATA = LATB = LATC = LATD = 0;//???*/


	TRISA = TRISA_CONF;	 				// '1' entree ; '0' sortie
	TRISB = TRISB_CONF;					// '1' entree ; '0' sortie
	TRISC = TRISC_CONF;	 				// '1' entree ; '0' sortie
	TRISD = TRISD_CONF;	 				// '1' entree ; '0' sortie
	TRISE = TRISE_CONF;	 				// 'PortE+ mode portD (p37) 1' entree ; '0' sortie


	INTCON = 0b0100000;					// # PIE pour USART
	PIE1   = 0b0010000;					// USART RCIE

/*	OPTION = OPTION_SET; 				// charge masque registre option
	INTCON = 0b01100000; 				// masque interruption, PIE, tmr0:RA4
	PIE1   = 0b00000001; 				// timer1
	//PIE2 = 0b00000000;
	T1CON = TMR1_SET;

	//========= INITIALISATION DES PERIPHERIQUES =========//

	init232(DebitSPBRG[DebitINIT]);	// port serie, pas de parite, 8bits, 1 stop
	i2c_init();								// initialisation Bus I2C
	TEMPO();
	lcd_init_both(64);					// initialisation du LCD (X=0, Y=0, Z=0)
*/
	///////ei();
}

//========================================================================================
// INTERRUPTIONS
//========================================================================================
void interrupt 
ISR(void)			//	The main ISR routine
{
	if (TMR0IE && TMR0IF)		// did the timer cause the interrupt?
	{
		TMR0 = 0xF000;
		TMR0IF = 0;
	}
	if (RBIE && RBIF)		// did something on PORTB change?
	{
		RBIF = 0;
	}

	if (RCIE && RCIF)		// did we receive serial I/O
	{
		bufferRX[indexRX] = RCREG;		// add to circular buffer
		indexRX++; 
		indexRX &= 0x3F;					// 64-1	=> %64
		RCIF = 0;
		serialRX = 1;
	}
}

void interrupt low_priority 
ISR_LOW(void) 
{ 

}


//========================================================================================
//   Menu dessin (test fct plot x,y)		// 200 octets ROM
//========================================================================================
void
menu_dessin(unsigned char clav, unsigned char *c_x, unsigned char *c_y){

switch(clav){
	case 1:	(*c_x)--;
				(*c_y)--;
				break;
	case 2:	(*c_x)--;
				break;
	case 3:	(*c_x)--;
				(*c_y)++;
				break;
	case 4:	(*c_y)--;
				break;
	case 5:	(*c_x) = 32;
				(*c_y) = 64;
				lcd_clear();
				lcd_string_loc_lc("Fenetre de dessin",0,13);
				break;
	case 6:	(*c_y)++;
				break;
	case 7:	(*c_x)++;
				(*c_y)--;
				break;
	case 8:	(*c_x)++;
				break;
	case 9:	(*c_x)++;
				(*c_y)++;
				break;
	} 
	if (clav)	{
		lcd_plot(*c_x, *c_y, 1);
		tempo_x65ms(3);
		lcd_uchar("Cx=", 7,  4, *c_x);
		lcd_uchar("Cy=", 7, 90, *c_y);
	}	
	if (*c_x==8)   *c_x = 55;		// 0 63
	if (*c_x==56)  *c_x = 8;		// 64 0
	if (*c_y==0)   *c_y = 127;
	if (*c_y==128) *c_y = 0;
}

//========================================================================================
// MAIN
//========================================================================================
main()
{
	unsigned char tmp, i, x = 32, y = 63, clav;
	init_system();								// I/O
	init232(DIVIDER);									// rs232
////	lcd_init();									// LCD HS44780


////	init232(DebitSPBRG[DebitINIT]);	// port serie, pas de parite, 8bits, 1 stop
	i2c_init();								// initialisation Bus I2C
	TEMPO();
	lcd_init_both(64);					// initialisation du LCD (X=0, Y=0, Z=0)


	tx232_puts("Hello PIC18F452\n\r");

	LUM_RL = 1;					// BackLight ON
	lcd_bitmap(bmp0);			// seb scope
	//tempo_x65ms(50);
	DelayBigMs(255);
	DelayBigMs(255);
	DelayBigMs(255);
	DelayBigMs(255);
	DelayBigMs(255);
	DelayBigMs(255);
	DelayBigMs(255);
	DelayBigMs(255);
	
	lcd_bitmap(bmp1);			// seb scope
	//tempo_x65ms(50);
	DelayBigMs(255);
	DelayBigMs(255);
	DelayBigMs(255);
	DelayBigMs(255);
	DelayBigMs(255);
	DelayBigMs(255);
	DelayBigMs(255);

	
	/*lcd_goto(0x00);
	lcd_puts("Hello PIC18F452");
	*/
	lcd_clear();
	//lcd_string_loc_lc("TEST_ABCD", 0, 0);
	


	// TEST LIGNES
	lcd_line(40, 10, 25, 15); 
	lcd_line(25, 15, 40, 20); 
	lcd_line(40, 20, 25, 30); 
	lcd_line(25, 30, 40, 36); 
	lcd_line(40, 36, 25, 37); 
	lcd_line(25, 37, 40, 45); 
	lcd_line(40, 45, 25, 67); 
	lcd_line(25, 67, 40, 69); 

	// Rectangle Bord
	lcd_line(0, 0, 63, 0); 
	lcd_line(0, 127, 63, 127); 
	lcd_line(0, 0, 0, 127); 
	lcd_line(63, 0, 63, 127); 

	// Croix
	lcd_line(0, 0, 63, 127); 
	lcd_line(0, 127, 63, 0); 
	
	cercle(32, 63, 16);			// cx, cy, radius

	cercle(20, 20, 10);			// cx, cy, radius
	cercle(37, 110, 8);			// cx, cy, radius
	cercle(45, 60, 29);			// cx, cy, radius
	cercle(0, 0, 12);			// cx, cy, radius
	
	lcd_string_loc_lc("TEST_ABCD", 7, 30);

	while(1) {
        DelayBigMs(250);
        DelayBigMs(250);
        if (RCIF) {
				tmp = rx232();
				tx232(tmp);	
				//lcd_line2();
				//lcd_goto(0x09);
				//lcd_putchar(tmp);


				if (tmp - '0' == 11) lcd_clear();        	
				menu_dessin(tmp - '0' , &x, &y);
        }

			clav = clavier();        
			if (clav != 0) {
				if (clav == 11) lcd_clear();     
				if (clav == 12) lcd_bitmap(bmp16);   	
				menu_dessin(clav, &x, &y);
				tx232_2ascii(clav);
			}
        
        /*if (serialRX==1) {
				serialRX = 0;
				tx232_puts("\n\rBuffRX[]=");
				lcd_line2();
				for(i=0; i!=indexRX; i++) {
					lcd_putchar(bufferRX[i]);
					tx232(bufferRX[i]);
				}
				tx232_puts("\n\r");			        
        }  */  
    
    }
    
} 


/*********************************************************************
 * FileName:        IOConfig.h
 * Dependencies:    See INCLUDES section below
 * Processor:       PIC18
 * Compiler:        C18 3.05 +
 * Company:         Microchip Technology, Inc.
 *
 *
 * Author               Date        Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Ernesto Pareja       23/12/07    Original.
 ********************************************************************/

#ifndef _IOCONFIG
#define _IOCONFIG

/** T R I S *********************************************************/
#define INPUT_PIN           1
#define OUTPUT_PIN          0



/** O T H E R   H A R D W A R E */


/** 1 2 8 x 6 4   L C D   I N T E R F A C E *******/
#define LCD_DataPort				PORTD
#define LCD_TrisDataPort		TRISD
#define	initLCDPort()				TRISC=0; LCD_DataPort=0; TRISD=0;TRISA=0;
#define LCD_PortInput()			TRISD = 0xFF;
#define LCD_CS1						PORTCbits.RC0		
#define LCD_CS2						PORTCbits.RC1		
#define LCD_E							PORTCbits.RC2		
#define LCD_DI						PORTCbits.RC6		
#define LCD_RW						PORTCbits.RC7		
#define LCD_RESET					PORTAbits.RA1

#define LCD_BACKLIGHT				0x00				// Not Used

#define ON		1
#define OFF		0

#endif
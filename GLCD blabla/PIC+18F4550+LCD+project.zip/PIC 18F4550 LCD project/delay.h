#ifndef _delay_H
#define _delay_H

void delay_ms(WORD time);

#endif



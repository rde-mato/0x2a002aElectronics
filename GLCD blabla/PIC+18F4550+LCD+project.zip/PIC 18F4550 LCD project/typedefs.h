
/*********************************************************************
 *
 *                Usual type definitions Version 1.0
 *
 *********************************************************************
 * FileName:        typedefs.h
 * Dependencies:    See INCLUDES section below
 * Processor:       PIC18
 * Compiler:        C18 3.05 +
 * Company:         
 *
 *
 * Author               Date        Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Ernesto Pareja       23/12/07    Original.
 ********************************************************************/

#ifndef TYPEDEFS_H
#define TYPEDEFS_H

/******** C O N S T A N T S  *******************************/
#define OK      	TRUE
#define FAIL    	FALSE

#define	us			0.6	// # Instrucciones ejecutadas en 1 us dividido 10 por Delay10TCYx
#define	ms			6		//	# Instrucciones ejecutadas en 1 ms. Deber�a ser 6000 pero es para poder usar Delay1KTCYx

/******** T Y P E   D E F I N I T I O N S ******************/
typedef unsigned char   byte;           // 8-bit
typedef unsigned int    word;           // 16-bit
typedef unsigned long   dword;          // 32-bit

typedef union _BYTE {
    byte _byte;
    struct {
        unsigned b0:1;
        unsigned b1:1;
        unsigned b2:1;
        unsigned b3:1;
        unsigned b4:1;
        unsigned b5:1;
        unsigned b6:1;
        unsigned b7:1;
    };
} BYTE;

typedef union _WORD {
    word _word;
    struct {
        byte byte0;
        byte byte1;
    };
    struct {
        BYTE Byte0;
        BYTE Byte1;
    };
    struct {
        BYTE LowB;
        BYTE HighB;
    };
    struct {
        byte v[2];
    };
} WORD;

#define LSB(a)      ((a).v[0])
#define MSB(a)      ((a).v[1])

typedef union _DWORD {
    dword _dword;
    struct {
        byte byte0;
        byte byte1;
        byte byte2;
        byte byte3;
    };
    struct {
        word word0;
        word word1;
    };
    struct {
        BYTE Byte0;
        BYTE Byte1;
        BYTE Byte2;
        BYTE Byte3;
    };
    struct {
        WORD Word0;
        WORD Word1;
    };
    struct {
        byte v[4];
    };
} DWORD;
#define LOWER_LSB(a)    ((a).v[0])
#define LOWER_MSB(a)    ((a).v[1])
#define UPPER_LSB(a)    ((a).v[2])
#define UPPER_MSB(a)    ((a).v[3])

typedef void(*pFunc)(void);

typedef union _POINTER {
    struct {
        byte bLow;
        byte bHigh;
        //byte bUpper;
    };
    word _word;                         // bLow & bHigh
    
    //pFunc _pFunc;                       // Usage: ptr.pFunc(); Init: ptr.pFunc = &<Function>;

    byte* bRam;                         // Ram byte pointer: 2 bytes pointer pointing
                                        // to 1 byte of data
    word* wRam;                         // Ram word poitner: 2 bytes poitner pointing
                                        // to 2 bytes of data

    rom byte* bRom;                     // Size depends on compiler setting
    rom word* wRom;
    //rom near byte* nbRom;               // Near = 2 bytes pointer
    //rom near word* nwRom;
    //rom far byte* fbRom;                // Far = 3 bytes pointer
    //rom far word* fwRom;
} POINTER;

typedef enum _BOOL { FALSE = 0, TRUE } BOOL;


/*****  M A C R O   D E F I N I T I O N S ********************/
#define HIGH(x) 	((unsigned)(x) >> 8)
#define LOW(x)  	((x) & 0xFF)
//#define BTF(x,b)	(((unsigned)(x)) ^ (0x01 << b)) // Bit Toggle
//#define BCF(x,b)	(((unsigned)(x)) & (0xFE << b))	// Bit Clear
//#define BSF(x,b)	(((unsigned)(x)) | (0x01 << b))	// Bit Set
//#define BTSTF(x,b)(((unsigned)(x)) & (0x01 << b)) // Bit Test
//
#define BTF(x,b)	((x) ^= (1 << (b)))	// Bit Toggle
#define BCF(x,b)	((x) &= ~(1 << (b)))	// Bit Clear
#define BSF(x,b)	((x) |= (1 << (b)))	// Bit Set
#define BTSTF(x,b)	(!!((x) & (1 << (b))))  // Bit test

#endif

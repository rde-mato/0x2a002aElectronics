

#include "typedefs.h"

//*********************************************************************
//************************  Delay MS Routine  *************************
//*********************************************************************
void delay_ms(WORD time)
{
    WORD x;

//    sim.pit[1].pmr = 0x4800;                    // set up reload values 0x4800 for 1ms counter
//    sim.pit[1].pcsr = 0x207;                    // set up divide ratio and options
//
//
//    for(x=0;x<time;x++)
//    {
//        while(!(sim.pit[1].pcsr & 0x0004));     // stay here while bit is clear
//        sim.pit[1].pcsr |= 0x0004;              // clear the Bit by setting the bit ;) 
//    }
//
}


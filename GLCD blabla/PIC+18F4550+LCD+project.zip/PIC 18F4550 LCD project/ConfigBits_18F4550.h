/*********************************************************************
 *
 *                Configuraci�n de Bits para un PIC 18F4550
 *
 *********************************************************************
 * FileName:        CinfigBits_18F4550.h
 * Dependencies:    See INCLUDES section below
 * Processor:       PIC18
 * Compiler:        C18 2.30.01+
 * Company:         Microchip Technology, Inc.
 *
 * La definci�n de la configuraci�n de Bits se puede encontrar por 
 * el men� de Help - Topics - PIC18 Config Settings
 *
 * Author               Date        Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Ernesto Pareja      25/11/07    Original.
 ********************************************************************/

/** C O N F I G U R A T I O N   B I T S **************************************/
#pragma config PLLDIV = 1 //   (divisi�n por 1 = 4 MHz Input)
#pragma config CPUDIV = OSC4_PLL6  //[OSC1/OSC2 Src: /3][96 MHz PLL Src: /4] 
#pragma config USBDIV = 2	//USB clock source comes from the 96 MHz PLL divided by 2 
#pragma config FOSC = INTOSC_HS // HSPLL_HS // HS oscillator, PLL enabled, HS used by USB  
//#pragma config FCMEM = OFF // Fail-Safe Clock Monitor disabled  
#pragma config IESO = OFF  // Oscillator Switchover mode disabled  
#pragma config PWRT = ON   // PWRT enabled  
#pragma config BOR = ON   //Brown-out Reset enabled in hardware only (SBOREN is disabled) 
#pragma config BORV = 2   // Minimum setting  (2 Volts)
#pragma config VREGEN = OFF  // USB voltage regulator enabled  
#pragma config WDT = OFF   // HW Disabled - SW Controlled  
#pragma config WDTPS = 32768  // 1:32768  
#pragma config MCLRE = ON // MCLR pin enabled; RE3 input pin disabled  
#pragma config LPT1OSC = OFF  //Timer1 configured for higher power operation  
#pragma config PBADEN = OFF  // PORTB<4:0> pins are configured as digital I/O on Reset  
#pragma config CCP2MX = OFF   // CCP2 input/output is multiplexed with RC1  
#pragma config STVREN = ON   // Stack full/underflow will cause Reset   
#pragma config LVP 		= OFF // Single-Supply ICSP disabled 
#pragma config ICPRT = OFF // ICPORT disabled  
#pragma config XINST = OFF   // Instruction set extension and Indexed Addressing mode disabled  
#pragma config DEBUG = OFF  // Background debugger disabled, RB6 and RB7 configured as general purpose I/O pins  
#pragma config CP0 = OFF   // Block 0 (000800-001FFFh) not code-protected  
#pragma config CP1 = OFF   // Block 1 (002000-003FFFh) not code-protected  
#pragma config CP2 = OFF   // Block 2 (004000-005FFFh) not code-protected 
#pragma config CP3 = OFF   // Block 3 (006000-007FFFh) not code-protected   
#pragma config CPD = OFF   // Data EEPROM not code-protected 
#pragma config WRT0 = OFF  // Block 0 (000800-001FFFh) not write-protected   
#pragma config WRT2 = OFF  // Block 2 (004000-005FFFh) not write-protected  
#pragma config WRT3 = OFF  // Block 3 (006000-007FFFh) not write-protected  
#pragma config WRTB = OFF  // Configuration registers (300000-3000FFh) not write-protected  
#pragma config WRTC = OFF  // Boot block (000000-0007FFh) not write-protected   
#pragma config WRTD = OFF  // Data EEPROM not write-protected  
#pragma config EBTR0 = OFF // Block 0 (000800-001FFFh) not protected from table reads executed in other blocks  
#pragma config EBTR1 = OFF // Block 1 (002000-003FFFh) not protected from table reads executed in other blocks  
#pragma config EBTR3 = OFF // Block 3 (006000-007FFFh) not protected from table reads executed in other blocks      
#pragma config EBTRB = OFF // Boot block (000000-0007FFh) not protected from table reads executed in other blocks   
 

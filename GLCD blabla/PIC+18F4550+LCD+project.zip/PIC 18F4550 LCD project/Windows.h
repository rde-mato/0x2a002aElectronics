/*********************************************************************
 *
 *       Library header for window interface in the 128x64 display
 *
 *********************************************************************
 * FileName:        Windows.c
 * Dependencies:    See INCLUDES section below
 * Processor:       PIC18
 * Compiler:        C18 3.05 +
 * Company:         
 *
 *
 * Author               Date        Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Ernesto Pareja       30 jun 2008   Original.
 ********************************************************************/



/****** T Y P E   D E F I N I T I O N S  &  S T R T U C T U R E S ***/

typedef struct {
	char x;
	char y;
	char * Caption;	
	rom char * font;
} TLabel;	

	
typedef struct {
	char Caption[5];
} TTAB;	





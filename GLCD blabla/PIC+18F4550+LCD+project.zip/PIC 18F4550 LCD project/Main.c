/*********************************************************************
 *
 *                LCD Display 128x64 test program
 *
 *********************************************************************
 * FileName:        main.c
 * Dependencies:    See INCLUDES section below
 * Processor:       PIC18F4550
 * Compiler:        C18 3.05 +
 * Company:         My personal use
 *
 * Notes:						Using www.crystalfontz.com libraries
 *
 * Author               Date        Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Ernesto Pareja       14/06/08    Original.
 ********************************************************************/

/** I N C L U D E S **********************************************************/
#include "p18cxxx.h"
#include "ConfigBits_18F4550.h" 
#include "IOConfig.h"
#include "typedefs.h"
#include "128x64_LCD.h"
#include "Font5x8.h"
#include "Font6x8.h"
#include "Font8x8F.h"
#include <math.h>
#include <delays.h>


/******** T Y P E   D E F I N I T I O N S ******************/
//void main (void);


/** C O N S T A N T S ********************************************************/
// *** GLOBAL VARIABLES ***



/** E E P R O M   D A T A   I N I T I A L I Z A T I O N***************************/
#pragma romdata eedata_scn=0xf00000
//rom char eedata_values[8] = {3, 0, 4, 0, 5, 0, 6, 0};
#pragma romdata


#pragma code


/** V E C T O R  R E M A P P I N G *******************************************/


/** P R I V A T E  P R O T O T Y P E S ***************************************/

void main (void) {
	char i,j, dato;


	
  EECON1bits.EEPGD = 0;		// Access EEPROM DATA Instead of Flash Program Memory
	EECON1bits.CFGS = 0;		// Access EEPROM Instead of Config Registers

	CMCON = 0x07;						// Ensure Comparator Module is off;
	UCFGbits.UTRDIS	= 1;		// Apaga el USB
	SPPCONbits.SPPEN = 0; // Apaga el m�dulo SPP
	LCD_Initalize();
	OSCCON = 0b11110011;

	TRISA = 0;
	TRISB = 0xFF;
	while (1) {	

		LCD_WriteCMD(0xC0,3);  							// Start Line at TOP of screen
		
		if (PORTBbits.RB2 == 1) {
			
			dato = 0xAA;			
			LCD_PutData(0,0,0xAA);
			
			dato = 0xFF;


			LCD_PutData(1,1,dato);
			LCD_PutData(2,2,dato);
			LCD_PutData(3,3,dato);
			LCD_PutData(4,4,dato);
			LCD_PutData(5,5,dato);
			LCD_PutData(6,6,dato);
			LCD_PutData(7,7,dato);
			LCD_PutData(8,7,dato);
			LCD_PutData(9,6,dato);
			LCD_PutData(10,5,dato);
			LCD_PutData(11,4,dato);
			LCD_PutData(12,3,dato);
			LCD_PutData(13,2,dato);
			LCD_PutData(14,1,dato);
			LCD_PutData(15,0,dato);
			dato = LCD_ReadData(0,0);
			LCD_PutData(0,2,dato);
			
			
		} 

		if (PORTBbits.RB3 == 1) {
			for (j=0;j<64;j++) {
				for (i=0;i<128;i++) {
					LCD_PixelPut(i,j);
				}	
			}
		}


		if (PORTBbits.RB1 == 1) {
			LCD_Cls(0xFF);
		} 
		if (PORTBbits.RB0 == 1) {
			LCD_Cls(0x00);
		} 
		
		if (PORTBbits.RB4 == 1) {
			for (j=0;j<4;j++) {
				for (i=0;i<128;i++) {
					dato = LCD_ReadData(i,j);
					dato = LCD_ReadData(i,j);
					LCD_PutData(i,j+4,dato);
				}
			}	
		} 

		if (PORTBbits.RB5 == 1) {

			LCD_FixedPrintf("Esto es prueba",&FONT8x8F[0],STYLE8x8,0,0);	
			LCD_Printf("Esto es prueba",&FONT8x8F[0],STYLE8x8,0,0);	
			LCD_Printf("Ernesto Pareja Jaramillo",&FONT6x8[0],STYLE6x8,0,10);	
			LCD_Printf("ABCDEFGHIJKL",&FONT5x8[0],STYLE5x8,0,20);
		} 
	}	
}


/*********************************************************************
 *
 *           Windows tabbed functions in the 128x64 display
 *
 *********************************************************************
 * FileName:        Windows.c
 * Dependencies:    See INCLUDES section below
 * Processor:       PIC18
 * Compiler:        C18 3.05 +
 * Company:         
 *
 *
 * Author               Date        Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Ernesto Pareja       30 jun 2008   Original.
 ********************************************************************/

/************** I N C L U D E S ********************************************/
#include "128x64_LCD.h"
#include "typedefs.h"
#include "windows.h"




/** P R I V A T E  P R O T O T Y P E S ***************************************/



/******************************************************************************
 * Function:        void DrawWindoTabs(void)
 * PreCondition:    None
 * Input:           None
 * Output:          None
 * Side Effects:    None
 * Overview:        Initializes the LCD 
 *
 * Note:            None
 *****************************************************************************/

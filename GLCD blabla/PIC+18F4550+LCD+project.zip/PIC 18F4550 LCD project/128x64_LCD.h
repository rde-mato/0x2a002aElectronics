/*********************************************************************
 *
 *                LCD Display 128x64 header file
 *
 *********************************************************************
 * FileName:        128x64_LCD.h
 * Dependencies:    See INCLUDES section below
 * Processor:       PIC18F4550
 * Compiler:        C18 3.05 +
 * Company:         My personal use
 *
 * Notes:						Using www.crystalfontz.com libraries
 *
 * Author               Date        Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Ernesto Pareja       14/06/08    Adapting the Original file.
 ********************************************************************/



#ifndef _128x64_LCD
#define _128x64_LCD



#define LCD_DATA(x)  				LCD_DataPort = x 	// write data and toggle it in

#define UPDATE_LCD       			TRUE
#define UPDATE_RAM					NULL

/*************** B I T   S T A T E   D E F I N I T I O N S *********/
#define LCD_CS1_HIGH				LCD_CS1 = 1      // PDATA L0
#define LCD_CS1_LOW					LCD_CS1 = 0     // PDATA L0

#define LCD_CS2_HIGH				LCD_CS2 = 1     // PDATA L1
#define LCD_CS2_LOW					LCD_CS2 = 0     // PDATA L1

#define LCD_DI_HIGH                 LCD_DI	= 1		// PDATA L4
#define LCD_DI_LOW                  LCD_DI  = 0     // PDATA L4

#define LCD_E_HIGH                  LCD_E = 1;  //E_Pulse_Delay();      // keep equal times  - PDATA L2
#define LCD_E_LOW                   LCD_E = 0;  // E_Pulse_Delay();      // keep equal times  - PDATA L2

#define LCD_RW_READ                  LCD_RW = 1;  //E_Pulse_Delay();      // keep equal times  - PDATA L2
#define LCD_RW_WRITE                 LCD_RW = 0;  //E_Pulse_Delay();      // keep equal times  - PDATA L2

#define LCD_TOGGLE_E			Nop();  LCD_E_HIGH; Nop(); Nop(); Nop(); LCD_E_LOW; Nop(); 	Nop(); 

#define LCD_BACKLIGHT_ON            0                   // Not Implemented 
#define LCD_BACKLIGHT_OFF           0                   // Not Implemented 


/*************** L C D   F O N T   D E F I N E   S I Z E S ******/
#define STYLE5x8					5
#define STYLE6x8					6
#define STYLE8x8					8

#define LCD_LINE_1				0
#define LCD_LINE_2				1
#define LCD_LINE_3				2
#define LCD_LINE_4				3
#define LCD_LINE_5				4
#define LCD_LINE_6				5
#define LCD_LINE_7				6
#define LCD_LINE_8				7





/*************** F U N C T I O N S   P R O T O T Y P E S ******/
void LCD_Initalize(void);
void E_Pulse_Delay(void);
void LCD_WriteCMD(char Command, char DispSide);
void LCD_GetTrueY(char *data, char y);
void LCD_GotoXY(char x, char y);
void LCD_PixelPut(char x, char y);
void LCD_PixelClr(char x, char y);
void LCD_PutData(char x, char y, char data);
char LCD_ReadData(char x, char y);
void LCD_Cls(char fill); 
//void LCD_Box(char x1, char y1, char x2, char y2, char pixel_on_off);
//void LCD_Line(char x1, char y1, char x2, char y2, char pixel_on_off);
void LCD_FixedPrintf(rom char *the_string, rom char *pfont_pointer, char font_size, char location_x, char LCDLine);
void LCD_Printf(rom char * the_string, rom char * pfont_pointer, char font_size, char location_x, char location_y);
void LCD_Logo(const char *pfont_pointer, char x_start, char y_start, char x_max, char y_max);
//void LCD_Circle(char center_x, char center_y, char r);








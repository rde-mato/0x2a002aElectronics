

/******************************************************************************
  Name:    			128x64 LCD.c package.  Full FONT Version
  Copyright: 		Free to use. not guaranteed to meet any requirements.
  Author: 			JCP
  Date: 			20/03/05 09:52
  Description:      Source Code to drive the 128x64, CFAG12864B-YYH-V LCD from
  					http://www.crystalfontz.com/

  Version:			v1.0
*******************************************************************************/


/************** I N C L U D E S ********************************************/
#include "p18cxxx.h"
#include "IOConfig.h"
#include "128x64_LCD.h"
#include "typedefs.h"
#include <delays.h>





/** P R I V A T E  P R O T O T Y P E S ***************************************/
void LCD_Data_toggle(void);


/******************************************************************************
 * Function:        void LCD_Initalize(void)
 * PreCondition:    None
 * Input:           None
 * Output:          None
 * Side Effects:    None
 * Overview:        Initializes the LCD 
 *
 * Note:            None
 *****************************************************************************/
void LCD_Initalize(void)
{
	LATD = 0;
	LATC = 0;
	initLCDPort()
	
	ADCON0 =0 ;
	ADCON1 = 0b00001111; // All digital inputs
	LCD_RESET = 0;
	Nop();
	Nop();
	Nop();
	Nop();
	Nop();
	LCD_RESET = 1;

	LCD_WriteCMD(0x3F,3);  // Turn Display on

	Nop();															//
	Nop();															//
	LCD_WriteCMD(0xC0,3);  							// Start Line at TOP of screen
}


/******************************************************************************
 * Function:        LCD_GetTrueY(char *data, char y)
 * PreCondition:    None
 * Author:          JCP  20/03/05 09:52
 * Input:           None
 * Output:          None
 * Side Effects:    None
 * Overview:        the LCD Y location is mapped out 0-7 however we need Y from 0-63
 *
 * Note:            None
 *****************************************************************************/
void LCD_GetTrueY(char *data, char y) {
	char x;												//
                                                        //
	data[0]=1;                                          // start @ 1 then 2,4,8,10,20,40,80
                                                        //
 	for(x=0;x<8;x++) {                                    // loop to find which actual Y(0-7) byte
   	if(y < 8) {                                       // for the LCD we are talking about
      data[0] <<=y;                               // search for the bit position on the true Y
			data[1] = x;                                // location
			return;                                     //
		}                                               //
                                                        //
		y -=8;                                          //
 	}                                                   //
}


/******************************************************************************
 * Function:        LCD_PixelPut(char x, char y)
 * PreCondition:    None
 * Author:          JCP  20/03/05 09:52
 * Input:           None
 * Output:          None
 * Side Effects:    None
 * Overview:        turn on one pixel on the LCD
 *
 * Note:            None
 *****************************************************************************/
void LCD_PixelPut(char x, char y) {
  
	char value[2];
//	char ActualDispData;

	if( (x < 128) && (y < 64) )	{					// protect system ram from user
		LCD_GetTrueY(value,y);
		LCD_ReadData(x,value[1]);
//		ActualDispData = LCD_ReadData(x,value[1]) | value[0];
		LCD_PutData(x,value[1],(LCD_ReadData(x,value[1]) | value[0]));

	}
}


/******************************************************************************
 * Function:        LCD_PixelClr(char x, char y)
 * PreCondition:    None
 * Author:          JCP  20/03/05 09:52
 * Input:           None
 * Output:          None
 * Side Effects:    None
 * Overview:        turn off one pixel on the LCD
 *
 * Note:            None
 *****************************************************************************/
void LCD_PixelClr(char x, char y)
{

 	char value[2];
//	char ActualDispData;


//	if( (x < 128) && (y < 64) )					// protect system ram from user
//	{
//		LCD_GetTrueY(value,y);
////		LCD_RAM[x][value[1]] &=~ value[0];
////		LCD_PutData(x,value[1],LCD_RAM[x][value[1]]);
//	}

	if( (x < 128) && (y < 64) )	{					// protect system ram from user
		LCD_GetTrueY(value,y);
		LCD_ReadData(x,value[1]);
//		ActualDispData = LCD_ReadData(x,value[1]) | value[0];
		LCD_PutData(x,value[1],(LCD_ReadData(x,value[1]) &~ value[0]));

	}
}


/******************************************************************************
 * Function:        void LCD_WriteCMD(char Command, char DispSide)
 * PreCondition:    None
 * Author:          Ernesto Pareja
 * Input:           None
 * Output:          None
 * Side Effects:    None
 * Overview:        Write a command on the LCD in the specified chip side or both
 *
 * Note:            None
 *****************************************************************************/
void LCD_WriteCMD(char Command, char DispSide) {
	LCD_E =  0;     
	switch (DispSide) {
		
		case 0:	LCD_CS1_HIGH; break;
		case 1: LCD_CS2_HIGH; break;
		default : { LCD_CS1_HIGH; LCD_CS2_HIGH; }
	}	

	LCD_RW_WRITE; 
	LCD_DI_LOW;							// RS or DI LOW as Commmand
	LCD_DATA(Command);			// Put the command on the DISP Port
	LCD_Data_toggle();

	LCD_CS1_LOW;
	LCD_CS2_LOW;
}	


/******************************************************************************
 * Function:        void LCD_GotoXY(char x, char y)
 * PreCondition:    None
 * Author:          Ernesto Pareja
 * Input:           None
 * Output:          None
 * Side Effects:    None
 * Overview:        Positions the LCD cursor on the specified x y coordinates
 *
 * Note:            None
 *****************************************************************************/
void LCD_GotoXY(char x, char y) {
	LCD_E =0;
	LCD_RW_WRITE;
	
	if( (x < 128) && (y < 8) ) {		// protect LCD from outboud ram access
		y |=0xB8;											// Set Page Register

		if(x > 0x3f) {  							// right side of screen ?
			LCD_CS2_HIGH;	
	  }  else {     								// left side of screen
    	LCD_CS1_HIGH; 	
    }

		x &= 0x3F;	// Mask the used bits and prevent x from being more than 64                                                //
		x |=0x40;		// Set Address Register Bit

		LCD_DI_LOW;
		LCD_DATA(x);						// Write Address Register
		LCD_Data_toggle();
	  LCD_DATA(y);   					// Write Page Register
		LCD_Data_toggle();
	}
	
}	



/******************************************************************************
 * Function:        LCD_PutData(char x, char y, char data)
 * PreCondition:    None
 * Author:          JCP  20/03/05 09:52
 * Input:           None
 * Output:          None
 * Side Effects:    None
 * Overview:        Put one byte of data on the LCD. NOTE: Y must be from 0-7, see data sheet
 *
 * Note:            None
 *****************************************************************************/
void LCD_PutData(char x, char y, char data) {
	//	if (ChangeCursor != 0){
		LCD_GotoXY(x,y);	
	//}
	LCD_DI_HIGH;							// set display for data mode
	LCD_DATA(data);						// pixel data to put on screen
	LCD_Data_toggle();
	LCD_DI_LOW;                             //
	LCD_CS1_LOW;                           // disable CS1
	LCD_CS2_LOW;                           // disable CS2
}


/******************************************************************************
 * Function:        char LCD_ReadData(char x, char y)
 * PreCondition:    None
 * Author:          Ernesto Pareja J
 * Input:           None
 * Output:          None
 * Side Effects:    When the coordinates have changed there must be a dummy read before
 *									reading the actual data
 * Overview:        Read one byte of data on the LCD. NOTE: Y must be from 0-7, see data sheet
 *
 * Note:            None
 *****************************************************************************/
char LCD_ReadData(char x, char y) {
	char data;

	LCD_GotoXY(x,y);	
	LCD_DI_HIGH;							// set display for data mode

	LATD = 0;
	TRISD = 0xFF;  // Display Data port as inputs
	LCD_RW_READ;
	Nop();
	LCD_E = 1;
	Nop();
	Nop();
	Nop();
	data = PORTD;
	Nop();
	LCD_E = 0;
	
	LCD_DI_LOW;
	LCD_RW_WRITE;
	
	LCD_CS1_LOW;                           // disable CS1
	LCD_CS2_LOW;                           // disable CS2
	
	LCD_TrisDataPort = 0x00; // Port as output
	return (data);
	
}	

/******************************************************************************
 * Function:        void LCD_Data_toggle()
 * PreCondition:    None
 * Author:          Ernesto Pareja J
 * Input:           None
 * Output:          None
 * Side Effects:    Toggles the Enable line On and off with an appropiate delay
 * Overview:        
 *
 * Note:            None
 *****************************************************************************/
void LCD_Data_toggle() {
	Nop();
	Nop();
	Nop();
	LCD_E_HIGH; 
	Nop();
	Nop();
	Nop();
	Nop();
	LCD_E_LOW; 
	Nop();
}	


/******************************************************************************
 * Function:        void LCD_Cls(char fill)
 * PreCondition:    None
 * Author:          Ernesto Pareja J
 * Input:           None
 * Output:          None
 * Side Effects:    None
 * Overview:        Fills the display with the character received as an input
 *
 * Note:            None
 *****************************************************************************/
void LCD_Cls(char fill) {
	char x,y;
	
 	for (y=0;y<8;y++) {
		for (x=0;x<128;x++) {
			LCD_PutData(x,y,fill);	
		}	 	
	}	
	
}



 /*****************************************************************************
  Name: 			LCD_FixedPrintf
  Copyright:        Free to use at will & at own risk.
  Author: 			JCP
  Date: 			17/03/05 17:10
  Description:      To Display a string in one of the 8 rows of the display.
  Useage:			LCD_Font_Fixed(param 1,param 2,param 3,param 4,param 5)

					param 1: string to be put on the LCD
					param 2: pointer for the font table
     			param 3: size of the font in columns
					param 4: x location in character spaces. 
					param 5: y location in character spaces.  all fonts Y = 0 - 7

	Example:        sprintf(thestring,"Hello World");
	
         			LCD_FixedFont(thestring,&FONT6x8[0][0],STYLE6x8,0,LINE_1,UPDATE_LCD);

*******************************************************************************/
void LCD_FixedPrintf(rom char *the_string, rom char *pfont_pointer, char font_size, char location_x, char LCDLine) {

	char x,y,z,e,last,pixel_step,loop,x_size,max_x;
	char font_char;
	rom char *font_pointer;


	pixel_step = location_x;							// pixel spaces we need to increase by
                                                            //
	while (*the_string != 0) {   // until it finds NULL terminator string
		font_pointer = pfont_pointer + (font_size * (int)(*the_string - 32));                                                            //
	 	z = 0x80;                                       
		e = 0x01;
		
			
		for(x=0;x < font_size;x++ )	{						// take the x location of font
			font_char=0;
			y=8;
			for (y=0 ; y<8 ; y++) {
				if (*font_pointer & z) {
					font_char |= e;				// This is because the font data is LSB at the top 
																// and we need it backwards
				}	
				z = z >> 1;
				e = e << 1;

			}	
			LCD_PutData(pixel_step,LCDLine,font_char);
			font_pointer++;
			z = 0x80;                              // point back to the first bit of the font
			e = 0x01;
			pixel_step++;	
	 	}

		the_string++; // Next character of the message
	}       
}



/******************************************************************************
	Name: 			LCD_Printf(rom char * the_string, rom char * pfont_pointer, char font_size, char location_x, char location_y)
  Author: 		JCP and modified by Ernesto Pareja J
  Date: 			29 jun 2008
  Description:    To Display a fixed size font (5x8, 6x8 or 8x8) in offset Y locations (0 - 63)
  Useage:			LCD_Font_Fixed(param 1,param 2,param 3,param 4,param 5,param 6)

			param 1: string to be put on the LCD
			param 2: pointer for the font table
  		param 3: size of the font in columns
			param 4: x location in character spaces from 0-127.
			param 5: y location in character spaces.  all fonts = 0 - 63

	Example:   LCD_Printf(thestring,&FONT6x8[0][0],STYLE6x8,0,0,UPDATE_LCD);

*******************************************************************************/
void LCD_Printf(rom char * the_string, rom char * pfont_pointer, char font_size, char location_x, char location_y) {

	char x,y,z,pixel_step,x_size;
	rom char * font_pointer;	
	char temp; //, temp2;	

	pixel_step = location_x;							// pixel spaces we need to increase by
                                                            //
	while (*the_string != 0) {   // until it finds NULL terminator string
		font_pointer = pfont_pointer + (font_size * (int)(*the_string - 32));                                                            //
	 	z = 0x80;                                           //

		for(x=0;x < font_size;x++ )	{						// take the x location of font

			y=8;
			do {
				y--;                               // rotate up...01, 02, 04, 08, 10...80
				if(*font_pointer & z)		{				//
					LCD_PixelPut(pixel_step,location_y + y);  // draw this in pixel mode
				}                                           //
				z = z >> 1;      
				
			} while (y>0);	
//			for(y=7; y>=0;y--)	{							// take the y location of the font
//			}                                               //
//                                                            //
			font_pointer++;                             //
			z=0x80;                              // point back to the first bit of the font
			pixel_step++;                                   //
	 	}                                                   //

		the_string++; // Next character of the message
	}       
                                                //
}                                                           //


/******************************************************************************
	Name: 			LCD_Logo
  	Copyright:      Free to use at will & at own risk.
  	Author: 		JCP
  	Date: 			17/03/05 17:10
  	Description:    To display LARGE logos on the LCD.
  	Useage:			LCD_Logo(param 1,param 2,param 3,param 4,param 5)

					param 1: pointer for the font table
					param 2: x location on screen, 0 - 127
					param 3: y location on screen, 0 - 63
     				param 4: total 8x8 blocks in the x direction
					param 5: total 8x8 blocks in the y direction

	Info:       	a 128 x 64 LCD gives you a max of 16 (8x8) blocks in the
 					x direction and a max of 8 (8x8) blocks in the y direction.
					When creating a logo draw your logo out in a grid of 128 x 64,
     				then when you are done block it out in a pattern of 8x8 blocks
					and see just how many 8x8 blocks your logo uses. this is how
					you arive with the last 2 parameters of param 4 & 5.

					In this demo the logo LMG took 12 (8x8) blocks in the X direction.
					and 4 (8x8) blocks in the y direction.

	Example:        LCD_Logo(&LMG[0][0],0,20,12,4);
*******************************************************************************/
void LCD_Logo(const char *pfont_pointer, char x_start, char y_start, char x_max, char y_max)
{

	char x,y,z,pixel_step,xloop,yloop,y_track;					
	const char *font_pointer;                              
                                                            	
	pixel_step =  x_start;                          			
	y_track=0;                                      	       
                                                                
	for(yloop=0;yloop < y_max;yloop++)  {                        
	  for(xloop=0;xloop < x_max;xloop++)    {                	
			font_pointer = pfont_pointer + (8 * y_track);  	   
			y_track++;                                      	
	  	z = 0x80;                                           
		                                                        
			for(x=0;x < 8;x++ )	 {		                       
				for(y=0;y < 8;y++)	{	                        
					if(*font_pointer & z)  {                    
						LCD_PixelPut(pixel_step,y_start + y);
					}                                          
					else  {        								// only need this if your going
						LCD_PixelClr(pixel_step,y_start + y);  // to scroll the LOGO
					}
	                                                           
					font_pointer++;                             
				}                                              
		                                                        
				font_pointer -= 8;                              
				z = z >> 1;                                    
				pixel_step++;                                  
		 	}                                                   
		}                                                       
		pixel_step = x_start; 		                         	
		y_start +=8;                                 			
	}                                                          
//  LCD_DisplayRam();							// show it when done writing to ram
																// comment out if you want to do this later
}

/******************************************************************************
 * Function:        LCD_Box(x1, y1, x2, y2, pixel_on_off)
 * PreCondition:    None
 * Author:          JCP  20/03/05 09:52
 * Input:           None
 * Output:          None
 * Side Effects:    None
 * Overview:        To put a BOX on the LCD, or delete a box off the LCD
 *
 * Note:            None
 *****************************************************************************/
void LCD_Box(char x1, char y1, char x2, char y2, char pixel_on_off) {
	char x,y;

 	if( (x1 < 128) && (x2 <128) && (y1 < 64) && (y2 < 64) )	{	// protect system from user 
    x = x1;
    y = y1;


  	while(x <= x2) {
			if(pixel_on_off) {
       	LCD_PixelPut(x,y1);
       	LCD_PixelPut(x,y2);
			}	else {
       	LCD_PixelClr(x,y1);
       	LCD_PixelClr(x,y2);
			}
	
			x++;
    }

  	while(y <= y2)  {
			if(pixel_on_off)	{
       	LCD_PixelPut(x1,y);
       	LCD_PixelPut(x2,y);
			}	else {
       	LCD_PixelClr(x1,y);
       	LCD_PixelClr(x2,y);
			}

			y++;
    }
	}
}
